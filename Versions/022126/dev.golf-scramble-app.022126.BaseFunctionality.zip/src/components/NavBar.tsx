import { Link, NavLink, useNavigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'

function A({ to, children }: { to: string; children: React.ReactNode }) {
  return (
    <NavLink
      to={to}
      style={({ isActive }) => ({
        padding: '8px 10px',
        borderRadius: 10,
        border: '1px solid transparent',
        background: isActive ? '#eef2ff' : 'transparent'
      })}
    >
      {children}
    </NavLink>
  )
}

export default function NavBar() {
  const { user, logout } = useAuth()
  const navigate = useNavigate()

  return (
    <div className="nav">
      <Link to="/" style={{ fontWeight: 700 }}>⛳ Golf Scramble</Link>
      <div className="navLinks">
        <A to="/">Home</A>
        <A to="/golf-logger">Golf Logger</A>
        <A to="/directions">Directions</A>
        {!user ? (
          <>
            <A to="/login">Login</A>
            <A to="/register">Register</A>
          </>
        ) : (
          <>
            <span className="small">Signed in as <strong>{user.email}</strong></span>
            <button className="btn" onClick={() => { logout(); navigate('/login') }}>Logout</button>
          </>
        )}
      </div>
    </div>
  )
}
