import express from 'express'
import cors from 'cors'
import fs from 'fs'
import path from 'path'
import bcrypt from 'bcryptjs'
import jwt from 'jsonwebtoken'
import { fileURLToPath } from 'url'
import { v4 as uuidv4 } from 'uuid'

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

const app = express()
app.use(express.json())

// When using Vite proxy, CORS isn't needed for the browser, but it helps if you hit the API directly.
app.use(cors({ origin: true }))

const PORT = 5000
const JWT_SECRET = process.env.JWT_SECRET || 'dev-only-secret-change-me'

const dataDir = path.join(__dirname, 'data')
const usersPath = path.join(dataDir, 'users.json')
const scoresPath = path.join(dataDir, 'scores.json')

function readJson(filePath, fallback) {
  try {
    return JSON.parse(fs.readFileSync(filePath, 'utf8'))
  } catch {
    return fallback
  }
}

function writeJson(filePath, data) {
  fs.writeFileSync(filePath, JSON.stringify(data, null, 2) + '\n', 'utf8')
}

function authMiddleware(req, res, next) {
  const header = req.headers.authorization || ''
  const token = header.startsWith('Bearer ') ? header.slice(7) : null
  if (!token) return res.status(401).json({ message: 'Missing token' })

  try {
    const payload = jwt.verify(token, JWT_SECRET)
    req.user = payload
    next()
  } catch {
    return res.status(401).json({ message: 'Invalid token' })
  }
}

app.get('/api/health', (req, res) => {
  res.json({ ok: true })
})

// ---- Auth ----
app.post('/api/auth/register', async (req, res) => {
  const { email, password } = req.body || {}
  if (!email || !password) return res.status(400).json({ message: 'Email and password required' })

  const users = readJson(usersPath, [])
  const exists = users.some(u => u.email.toLowerCase() === String(email).toLowerCase())
  if (exists) return res.status(409).json({ message: 'Email already registered' })

  const passwordHash = await bcrypt.hash(String(password), 10)
  const user = { id: uuidv4(), email: String(email), passwordHash, createdAt: new Date().toISOString() }
  users.push(user)
  writeJson(usersPath, users)

  return res.status(201).json({ message: 'Registered' })
})

app.post('/api/auth/login', async (req, res) => {
  // "Username" on the UI maps to email for now
  const { username, password } = req.body || {}
  if (!username || !password) return res.status(400).json({ message: 'Username and password required' })

  const users = readJson(usersPath, [])
  const user = users.find(u => u.email.toLowerCase() === String(username).toLowerCase())
  if (!user) return res.status(401).json({ message: 'Invalid credentials' })

  const ok = await bcrypt.compare(String(password), user.passwordHash)
  if (!ok) return res.status(401).json({ message: 'Invalid credentials' })

  const token = jwt.sign({ sub: user.id, email: user.email }, JWT_SECRET, { expiresIn: '7d' })
  return res.json({ token, user: { id: user.id, email: user.email } })
})

app.get('/api/auth/me', authMiddleware, (req, res) => {
  res.json({ user: { id: req.user.sub, email: req.user.email } })
})

// ---- Scores ----
app.get('/api/scores', authMiddleware, (req, res) => {
  const scores = readJson(scoresPath, [])
  // For now, scores are global; could be per-user later.
  res.json(scores)
})

app.post('/api/scores', authMiddleware, (req, res) => {
  const { date, course, team, opponentTeam, teamTotal, opponentTotal, money, holes } = req.body || {}
  if (!date || !course || !team) return res.status(400).json({ message: 'date, course, team required' })
  if (typeof teamTotal !== 'number') return res.status(400).json({ message: 'teamTotal must be a number' })
  if (typeof opponentTotal !== 'number') return res.status(400).json({ message: 'opponentTotal must be a number' })
  if (typeof money !== 'number') return res.status(400).json({ message: 'money must be a number (positive = won, negative = lost)' })

  const won = teamTotal < opponentTotal ? true : (teamTotal > opponentTotal ? false : null)

  const scores = readJson(scoresPath, [])
  const entry = {
    id: uuidv4(),
    date,
    course,
    team,
    opponentTeam: opponentTeam || '',
    teamTotal,
    opponentTotal,
    money,
    won, // true/false/null for tie
    holes: Array.isArray(holes) ? holes : null,
    createdAt: new Date().toISOString()
  }
  scores.unshift(entry)
  writeJson(scoresPath, scores)
  res.status(201).json(entry)
})

app.delete('/api/scores/:id', authMiddleware, (req, res) => {
  const id = req.params.id
  const scores = readJson(scoresPath, [])
  const next = scores.filter(s => s.id !== id)
  writeJson(scoresPath, next)
  res.json({ ok: true })
})

app.listen(PORT, () => {
  console.log(`API server listening on http://localhost:${PORT}`)
})
